print("--- CALCULADORA v1 ---")
a = float(input("Ingresa el primer número: "))
b = float(input("Ingresa el segundo número: "))

resta = a - b
suma = a + b

print(f"El resultado de la resta es: {resta}")
print(f"El resultado de la suma es: {suma}")